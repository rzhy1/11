#include <config.h>
#define SAME_INODE_INLINE _GL_EXTERN_INLINE
#include "same-inode.h"
